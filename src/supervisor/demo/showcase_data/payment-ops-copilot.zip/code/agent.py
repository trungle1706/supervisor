"""MLflow pyfunc entry of the payments operations agent (candidate A3, synthetic).

One call = one reconciliation and payment job. There is no approval step and no interrupt:
the agent plans and executes alone, inside the bounds of RunState. The control is the
Supervisor gate, wired in payops/tools.py with @supervised_tool.
"""
import os

from payops.bank import FakeCoreBank
from payops.config import Settings
from payops.gate import build_http_gate
from payops.planner import run_job
from payops.runstate import RunState
from payops.scenarios import SCENARIOS


class PayopsAgent:
    def predict(self, context, model_input, params=None):
        name = str((model_input or {}).get("scenario", "clean"))
        sc = SCENARIOS[name]
        s = Settings.from_env()
        run = RunState(name, sc["statement_id"], sc["instruction"], s.max_steps, s.max_total_minor, account=sc["account"])
        run_job(run, s, FakeCoreBank.seeded(), build_http_gate(s))
        return run.public()
