"""OAuth for a Databricks model serving endpoint (OpenAI-compatible route).

The App service principal gets a fresh token from the databricks-sdk for every request, so a
long run never uses an expired token. Never reads DATABRICKS_TOKEN. Not tested on a live
workspace (listed in the README as a live check)."""

from __future__ import annotations

import httpx


class DatabricksOAuth(httpx.Auth):
    def __init__(self, config: object | None = None) -> None:
        if config is None:
            from databricks.sdk.core import Config  # type: ignore[import-not-found]

            config = Config()
        self._config = config

    def auth_flow(self, request: httpx.Request):  # type: ignore[no-untyped-def]
        header = self._config.authenticate()  # type: ignore[attr-defined]
        request.headers["Authorization"] = header["Authorization"]
        yield request
