"""In-process fake core banking with seeded SYNTHETIC Vietnamese data.

Money is an integer number of VND (VND has no minor unit: 1 VND = 1). Never a float.
Nothing here talks to a network. The data is invented: names, CCCD numbers and account
numbers do not belong to real people.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from typing import Any

OPS_ACCOUNT = "ACC-OPS-001"      # scenario "clean"
OPS_ACCOUNT_2 = "ACC-OPS-002"    # scenario "limits" (its own account, so the daily windows do not mix)
OPS_CUSTOMER = "CUST-0001"
OPS_BALANCE = 2_000_000_000  # VND per account


class BankError(Exception):
    """A business refusal of the fake core (unknown payee, double payment, no funds)."""


def _check_int(name: str, value: Any) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise BankError(f"{name} must be an integer number of VND")
    return value


# ---- seed data ----------------------------------------------------------------------------
# Existing payees (already in the payee book).
SEED_PAYEES: list[dict[str, Any]] = [
    {"payee_id": "PAYEE-001", "name": "Cong ty CP Vat tu Xay dung Sao Mai (synthetic)",
     "account_number": "0711000123456", "bank_code": "VCB", "cccd": None},
    {"payee_id": "PAYEE-002", "name": "Cong ty TNHH Bao bi Thanh Cong (synthetic)",
     "account_number": "19031234567011", "bank_code": "TCB", "cccd": None},
    {"payee_id": "PAYEE-003", "name": "Cong ty TNHH Co khi Dai Phat (synthetic)",
     "account_number": "0451002233445", "bank_code": "VCB", "cccd": None},
    {"payee_id": "PAYEE-004", "name": "Cong ty CP Van tai Bien Dong (synthetic)",
     "account_number": "19036677889900", "bank_code": "TCB", "cccd": None},
]

# Supplier master data as it sits on the invoice (used when a payee has to be added).
SUPPLIERS: dict[str, dict[str, Any]] = {
    "SUP-NEW-01": {"payee_name": "Tran Van Minh (ca nhan, synthetic)", "cccd": "079085012345",
                   "account_number": "19038899001122", "bank_code": "TCB"},
}

# invoice_id -> invoice. payee_id is None when the supplier is not in the payee book yet.
SEED_INVOICES: list[dict[str, Any]] = [
    # scenario "clean": three invoices, one needs a new payee
    {"invoice_id": "INV-1001", "supplier_ref": "PAYEE-001", "amount_minor": 18_500_000, "status": "open"},
    {"invoice_id": "INV-1002", "supplier_ref": "PAYEE-002", "amount_minor": 42_000_000, "status": "open"},
    {"invoice_id": "INV-1003", "supplier_ref": "SUP-NEW-01", "amount_minor": 27_300_000, "status": "open"},
    # scenario "limits": one 150,000,000 invoice and three 45,000,000 to one payee
    {"invoice_id": "INV-2001", "supplier_ref": "PAYEE-003", "amount_minor": 150_000_000, "status": "open"},
    {"invoice_id": "INV-2002", "supplier_ref": "PAYEE-004", "amount_minor": 45_000_000, "status": "open"},
    {"invoice_id": "INV-2003", "supplier_ref": "PAYEE-004", "amount_minor": 45_000_000, "status": "open"},
    {"invoice_id": "INV-2004", "supplier_ref": "PAYEE-004", "amount_minor": 45_000_000, "status": "open"},
    {"invoice_id": "INV-2005", "supplier_ref": "PAYEE-001", "amount_minor": 12_000_000, "status": "open"},
]

# Bank statements: lines are payment advices to settle (reference text + amount).
SEED_STATEMENTS: dict[str, dict[str, Any]] = {
    "STM-2026-10-A": {"lines": [
        {"line_id": "A1", "reference": "TT HD INV-1001 SAO MAI", "amount_minor": 18_500_000},
        {"line_id": "A2", "reference": "TT HD INV-1002 THANH CONG", "amount_minor": 42_000_000},
        {"line_id": "A3", "reference": "TT HD INV-1003 TRAN VAN MINH", "amount_minor": 27_300_000},
    ]},
    "STM-2026-10-B": {"lines": [
        {"line_id": "B1", "reference": "TT HD INV-2001 DAI PHAT", "amount_minor": 150_000_000},
        {"line_id": "B2", "reference": "TT HD INV-2002 BIEN DONG", "amount_minor": 45_000_000},
        {"line_id": "B3", "reference": "TT HD INV-2003 BIEN DONG", "amount_minor": 45_000_000},
        {"line_id": "B4", "reference": "TT HD INV-2004 BIEN DONG", "amount_minor": 45_000_000},
        {"line_id": "B5", "reference": "TT HD INV-2005 SAO MAI", "amount_minor": 12_000_000},
        {"line_id": "B6", "reference": "TT HD INV-9999 UNKNOWN", "amount_minor": 5_000_000},
    ]},
}


@dataclass
class FakeCoreBank:
    balances: dict[str, int] = field(default_factory=dict)
    payees: dict[str, dict[str, Any]] = field(default_factory=dict)
    invoices: dict[str, dict[str, Any]] = field(default_factory=dict)
    transfers: list[dict[str, Any]] = field(default_factory=list)
    _lock: threading.Lock = field(default_factory=threading.Lock)
    _seq: int = 0

    @classmethod
    def seeded(cls) -> "FakeCoreBank":
        b = cls()
        b.balances = {OPS_ACCOUNT: OPS_BALANCE, OPS_ACCOUNT_2: OPS_BALANCE}
        b.payees = {p["payee_id"]: dict(p) for p in SEED_PAYEES}
        b.invoices = {i["invoice_id"]: dict(i) for i in SEED_INVOICES}
        return b

    @property
    def balance(self) -> int:
        """Balance of the first operating account (tests and /bank)."""
        return self.balances[OPS_ACCOUNT]

    # ---- reads -------------------------------------------------------------------------
    def reconcile(self, statement_id: str) -> dict[str, Any]:
        """Match each statement line to an open invoice by reference and exact amount."""
        st = SEED_STATEMENTS.get(str(statement_id))
        if st is None:
            raise BankError(f"unknown statement {statement_id}")
        matched: list[dict[str, Any]] = []
        exceptions: list[dict[str, Any]] = []
        for line in st["lines"]:
            inv = next((i for i in self.invoices.values() if i["invoice_id"] in line["reference"]), None)
            if inv is None:
                exceptions.append({"line_id": line["line_id"], "reason": "no invoice for reference",
                                   "amount_minor": line["amount_minor"]})
                continue
            if inv["status"] != "open":
                exceptions.append({"line_id": line["line_id"], "invoice_id": inv["invoice_id"],
                                   "reason": f"invoice is {inv['status']}"})
                continue
            if inv["amount_minor"] != line["amount_minor"]:
                exceptions.append({"line_id": line["line_id"], "invoice_id": inv["invoice_id"],
                                   "reason": "amount differs from invoice"})
                continue
            ref = inv["supplier_ref"]
            row: dict[str, Any] = {"line_id": line["line_id"], "invoice_id": inv["invoice_id"],
                                   "amount_minor": inv["amount_minor"]}
            if ref in self.payees:
                row["payee_id"] = ref
                row["payee_name"] = self.payees[ref]["name"]
            else:
                row["payee_id"] = None
                row["new_payee_details"] = dict(SUPPLIERS[ref])
            matched.append(row)
        return {"statement_id": statement_id, "matched": matched, "exceptions": exceptions}

    # ---- writes ------------------------------------------------------------------------
    def add_payee(self, customer_id: str, payee_name: str, cccd: str | None,
                  account_number: str, bank_code: str) -> dict[str, Any]:
        with self._lock:
            if customer_id != OPS_CUSTOMER:
                raise BankError("unknown customer")
            for p in self.payees.values():
                if p["account_number"] == account_number and p["bank_code"] == bank_code:
                    return {"payee_id": p["payee_id"], "created": False}
            self._seq += 1
            pid = f"PAYEE-N{self._seq:03d}"
            self.payees[pid] = {"payee_id": pid, "name": payee_name, "cccd": cccd,
                                "account_number": account_number, "bank_code": bank_code}
            return {"payee_id": pid, "created": True}

    def transfer(self, from_account_id: str, payee_id: str, amount_minor: int,
                 invoice_id: str, memo: str = "") -> dict[str, Any]:
        amount_minor = _check_int("amount_minor", amount_minor)
        with self._lock:
            if from_account_id not in self.balances:
                raise BankError("unknown source account")
            if payee_id not in self.payees:
                raise BankError(f"unknown payee {payee_id}")
            if amount_minor <= 0:
                raise BankError("amount must be positive")
            inv = self.invoices.get(invoice_id)
            if inv is None or inv["status"] != "open":
                raise BankError(f"invoice {invoice_id} is not open")
            if inv["amount_minor"] != amount_minor:
                raise BankError("amount differs from invoice")
            if self.balances[from_account_id] < amount_minor:
                raise BankError("insufficient funds")
            self.balances[from_account_id] -= amount_minor
            inv["status"] = "paid"
            tid = f"TXN-{len(self.transfers) + 1:05d}"
            rec = {"transfer_id": tid, "from_account_id": from_account_id, "payee_id": payee_id,
                   "amount_minor": amount_minor, "invoice_id": invoice_id}
            self.transfers.append(rec)
            return {**rec, "status": "executed",
                         "balance_minor": self.balances[from_account_id]}
