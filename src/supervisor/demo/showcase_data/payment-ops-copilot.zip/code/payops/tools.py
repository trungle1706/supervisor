"""The three bank tools. Each one is wrapped with the Supervisor SDK decorator
``@supervised_tool`` so every call is checked by the gate before the fake core runs.

Layers, outside in:  LLM-facing tool (agent guards) -> @supervised_tool (gate) -> fake core bank.
The agent guards are stricter than the gate on purpose: bounds of the run, integer VND, and no
retry around a block. They never replace the gate.
"""

from __future__ import annotations

import json
from typing import Any

from langchain_core.tools import StructuredTool
from supervisor.gateway.sdk import SupervisorBlocked, SupervisorPaused, supervised_tool

from .bank import OPS_CUSTOMER, BankError, FakeCoreBank
from .config import Settings
from .gate import RunGate
from .runstate import RunHalted, RunState

# Infrastructure refusals: the gate could not decide. Nothing more can be paid safely.
INFRA_RULES = {"GATE-MISSING", "GATE-ERROR", "GATE-UNREACHABLE", "GATE-AUTH", "GATE-DIRECTION"}

BLOCK_NOTE = (
    "The Supervisor gate refused this call. Do NOT retry it, do NOT change the amount, do NOT "
    "split it, do NOT use another payee or tool. Record it as an exception and go on with the "
    "other invoices."
)


def make_tools(
    run: RunState, bank: FakeCoreBank, gate: RunGate, s: Settings
) -> list[StructuredTool]:
    aid, ver = s.agent_id, s.agent_version

    # ---- gated tool bodies (what the gate protects) ------------------------------------
    @supervised_tool(aid, ver, "reconcile", "read_only", gate=gate)
    def reconcile(statement_id: str) -> dict[str, Any]:
        return bank.reconcile(statement_id)

    @supervised_tool(aid, ver, "add_payee", "pii_export", gate=gate)
    def add_payee(
        customer_id: str, payee_name: str, cccd: str, account_number: str, bank_code: str
    ) -> dict[str, Any]:
        return bank.add_payee(customer_id, payee_name, cccd, account_number, bank_code)

    @supervised_tool(aid, ver, "transfer", "money", gate=gate)
    def transfer(
        from_account_id: str, payee_id: str, amount_minor: int, invoice_id: str, memo: str = ""
    ) -> dict[str, Any]:
        return bank.transfer(from_account_id, payee_id, amount_minor, invoice_id, memo)

    # ---- agent-side guards + error mapping ----------------------------------------------
    def run_gated(label: str, fn: Any, **kw: Any) -> dict[str, Any]:
        """Call a gated body. Pause and infra refusals halt the run; a block is returned."""
        try:
            out = fn(**kw)
            return {"status": "ok", "result": out}
        except SupervisorPaused as exc:
            run.note("paused", tool=label, rule_id=exc.decision.get("rule_id"))
            raise RunHalted("SUPERVISOR_PAUSE", str(exc.decision.get("rule_id"))) from exc
        except SupervisorBlocked as exc:
            rule = str(exc.decision.get("rule_id"))
            if rule in INFRA_RULES:
                run.note("gate_unavailable", tool=label, rule_id=rule)
                raise RunHalted("GATE_UNAVAILABLE", rule) from exc
            run.note("blocked", tool=label, rule_id=rule)
            return {"status": "BLOCKED", "rule_id": rule,
                    "reason": str(exc.decision.get("reason", "")), "instruction": BLOCK_NOTE}
        except BankError as exc:
            run.note("bank_error", tool=label, error=str(exc))
            return {"status": "BANK_ERROR", "error": str(exc)}

    def reconcile_tool(statement_id: str) -> str:
        run.take_step()
        run.note("call", tool="reconcile", statement_id=statement_id)
        return json.dumps(run_gated("reconcile", reconcile, statement_id=statement_id))

    def add_payee_tool(payee_name: str, cccd: str, account_number: str, bank_code: str) -> str:
        run.take_step()
        run.note("call", tool="add_payee", bank_code=bank_code)
        out = run_gated(
            "add_payee", add_payee, customer_id=OPS_CUSTOMER, payee_name=payee_name,
            cccd=cccd, account_number=account_number, bank_code=bank_code,
        )
        return json.dumps(out)

    def transfer_tool(payee_id: str, amount_minor: int, invoice_id: str, memo: str = "") -> str:
        run.take_step()
        run.note("call", tool="transfer", payee_id=payee_id, amount_minor=amount_minor,
                 invoice_id=invoice_id)
        if isinstance(amount_minor, bool) or not isinstance(amount_minor, int) or amount_minor <= 0:
            return json.dumps({"status": "REFUSED_BY_AGENT", "reason": "amount_minor must be a positive integer number of VND"})
        # no retry around a block: the same invoice or the same payee is not tried again
        if invoice_id in run.blocked_invoices or payee_id in run.blocked_payees:
            run.note("no_retry_guard", invoice_id=invoice_id, payee_id=payee_id)
            return json.dumps({"status": "REFUSED_BY_AGENT", "reason": "NO_RETRY_AFTER_BLOCK",
                               "instruction": BLOCK_NOTE})
        if run.moved_minor + amount_minor > run.max_total_minor:
            raise RunHalted("MAX_TOTAL_VND", f"{run.moved_minor}+{amount_minor}>{run.max_total_minor}")
        out = run_gated(
            "transfer", transfer, from_account_id=run.account, payee_id=payee_id,
            amount_minor=amount_minor, invoice_id=invoice_id, memo=memo,
        )
        if out["status"] == "BLOCKED":
            run.blocked_invoices.add(invoice_id)
            run.blocked_payees.add(payee_id)
        elif out["status"] == "ok":
            run.moved_minor += amount_minor
            run.note("executed", transfer_id=out["result"].get("transfer_id"), amount_minor=amount_minor,
                     invoice_id=invoice_id)
        return json.dumps(out)

    return [
        StructuredTool.from_function(
            reconcile_tool, name="reconcile",
            description="Match the lines of a bank statement against open invoices. Read only. "
                        "Returns matched lines (invoice_id, payee_id, amount_minor in whole VND) "
                        "and exceptions. If payee_id is null the matched line has new_payee_details.",
        ),
        StructuredTool.from_function(
            add_payee_tool, name="add_payee",
            description="Add a payee to the payee book. Use only for a matched line whose payee_id "
                        "is null, with the new_payee_details from reconcile. Returns payee_id.",
        ),
        StructuredTool.from_function(
            transfer_tool, name="transfer",
            description="Pay one matched invoice from the operating account. amount_minor is a "
                        "whole number of VND (integer, no decimals) equal to the invoice amount.",
        ),
    ]
