"""Gate client wiring: HttpGate from the Supervisor SDK with the WP20 credential, plus a thin
wrapper that adds the run's session id, consumer id and turn text, and keeps a decision log.

Fail closed: no URL means no gate means every tool call is blocked (GATE-MISSING)."""

from __future__ import annotations

import hashlib
import threading
from collections.abc import Mapping
from typing import Any

from supervisor.gateway.ingress_sign import IngressCredential, credential_from_env
from supervisor.gateway.sdk import HttpGate

from .config import Settings


def build_credential(s: Settings) -> IngressCredential | None:
    if s.credential_kind == "databricks_oauth":
        # App service principal token, refreshed by the databricks-sdk (optional dependency).
        from databricks.sdk.core import Config  # type: ignore[import-not-found]

        cfg = Config()

        def token() -> str:
            hdr = cfg.authenticate()
            return str(hdr["Authorization"]).split(" ", 1)[1]

        return IngressCredential(s.agent_id, bearer=token)
    if s.credential:
        return IngressCredential(s.agent_id, s.credential)
    if s.credential_file:
        return credential_from_env(s.agent_id, s.credential_file)
    return None


def build_http_gate(s: Settings) -> HttpGate | None:
    if not s.gate_url:
        return None
    fail_modes = {"reconcile": "read_only", "write_todos": "read_only"} if s.gate_fail_open_read_only else {}
    return HttpGate(
        s.gate_url,
        timeout_s=s.gate_timeout_s,
        fail_modes=fail_modes,
        credential=build_credential(s),
    )


class RunGate:
    """GateHook for one run. Adds session_id / consumer_id (and turn_text on the first call)."""

    def __init__(self, inner: Any, run_id: str, consumer_id: str, turn_text: str) -> None:
        self.inner = inner
        self.run_id = run_id
        self.consumer_id = consumer_id
        self._turn_text = turn_text
        self._first = True
        self._lock = threading.Lock()
        self.log: list[dict[str, Any]] = []

    def check(
        self,
        agent_id: str,
        agent_version: str,
        tool_name: str,
        args: Mapping[str, Any],
        context: Mapping[str, Any] | None = None,
    ) -> Mapping[str, Any]:
        ctx = dict(context or {})
        ctx["session_id"] = self.run_id
        ctx["consumer_id"] = self.consumer_id
        with self._lock:
            if self._first:
                ctx["turn_text"] = self._turn_text
                self._first = False
        if self.inner is None:
            decision: Mapping[str, Any] = {
                "allow": False, "action": "block", "rule_id": "GATE-MISSING",
                "reason": "no gate configured: fail closed",
            }
        else:
            decision = self.inner.check(agent_id, agent_version, tool_name, args, ctx)
        self.log.append(summarise(tool_name, args, decision))
        return decision


def summarise(tool: str, args: Mapping[str, Any], d: Mapping[str, Any]) -> dict[str, Any]:
    """A log row without personal data: amounts and ids are kept, CCCD / account never."""
    pii = {"cccd", "account_number", "payee_name"}
    row: dict[str, Any] = {
        "tool": tool,
        "args": {k: v for k, v in args.items() if k not in pii},
        "args_pii_sha8": {
            k: hashlib.sha256(str(v).encode()).hexdigest()[:8] for k, v in args.items() if k in pii
        },
        "allow": d.get("allow"),
        "action": d.get("action"),
        "status": d.get("status"),
        "rule_id": d.get("rule_id"),
        "reason": d.get("reason"),
    }
    for k in ("mode", "observed_decision", "kept_args", "session_id", "correlation_id"):
        if d.get(k) is not None:
            row[k] = d[k]
    ta = d.get("transformed_args")
    if isinstance(ta, Mapping):
        kept = set(d.get("kept_args") or [])
        # masked by the gate; an argument the policy keeps as sent is not copied into the log
        row["transformed_args"] = {k: ("<kept as sent>" if k in kept else v) for k, v in ta.items()}
    return row
