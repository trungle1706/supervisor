"""Environment configuration. No secrets in code or files: values come from the environment
(Databricks App: app.yaml env + secret resource; laptop: shell)."""

from __future__ import annotations

import os
from dataclasses import dataclass


def _int(name: str, default: int) -> int:
    raw = os.environ.get(name, "").strip()
    return int(raw) if raw else default


@dataclass(frozen=True)
class Settings:
    llm_base_url: str
    llm_model: str
    llm_api_key: str
    llm_auth: str              # static (API key) | databricks_oauth (App service principal)
    gate_url: str
    agent_id: str
    agent_version: str
    credential: str            # HMAC secret (value) - from a secret, never a file in git
    credential_file: str       # or a path to a chmod 600 key file (laptop)
    credential_kind: str       # hmac | databricks_oauth
    consumer_id: str
    gate_timeout_s: float
    gate_fail_open_read_only: bool
    max_steps: int             # tool calls per run
    max_total_minor: int       # VND moved per run, integer
    llm_timeout_s: int
    llm_temperature_milli: int

    @classmethod
    def from_env(cls) -> "Settings":
        return cls(
            llm_base_url=os.environ.get("LLM_BASE_URL", "http://127.0.0.1:8001/v1"),
            llm_model=os.environ.get("LLM_MODEL", "qwen3.8-27b-int4"),
            llm_api_key=os.environ.get("LLM_API_KEY", "none"),
            llm_auth=os.environ.get("LLM_AUTH", "static"),
            gate_url=os.environ.get("SUPERVISOR_GATE_URL", ""),
            agent_id=os.environ.get("SUPERVISOR_AGENT_ID", "payment-ops-copilot"),
            agent_version=os.environ.get("SUPERVISOR_AGENT_VERSION", "1.0.0"),
            credential=os.environ.get("SUPERVISOR_CREDENTIAL", ""),
            credential_file=os.environ.get("SUPERVISOR_CREDENTIAL_FILE", ""),
            credential_kind=os.environ.get("SUPERVISOR_CREDENTIAL_KIND", "hmac"),
            consumer_id=os.environ.get("SUPERVISOR_CONSUMER_ID", "payops-desk"),
            gate_timeout_s=float(os.environ.get("GATE_TIMEOUT_S", "15")),
            # default closed for every tool. Open only a read_only tool, only when asked.
            gate_fail_open_read_only=os.environ.get("GATE_FAIL_OPEN_READ_ONLY", "0") == "1",
            max_steps=_int("PAYOPS_MAX_STEPS", 30),
            max_total_minor=_int("PAYOPS_MAX_TOTAL_VND", 300_000_000),
            llm_timeout_s=_int("LLM_TIMEOUT_S", 180),
            llm_temperature_milli=_int("LLM_TEMPERATURE_MILLI", 0),
        )
