"""State of one run and the bounds of the planner loop (code, not prompt)."""

from __future__ import annotations

import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any


class RunHalted(Exception):
    """The run must stop now (paused by Supervisor, a bound was reached, gate refused credential)."""

    def __init__(self, reason: str, detail: str = "") -> None:
        self.reason = reason
        self.detail = detail
        super().__init__(f"{reason}: {detail}" if detail else reason)


@dataclass
class RunState:
    scenario: str
    statement_id: str
    instruction: str
    max_steps: int
    max_total_minor: int
    account: str = "ACC-OPS-001"   # operating account this run pays from
    run_id: str = field(default_factory=lambda: "run" + uuid.uuid4().hex[:12])
    status: str = "pending"            # pending running done halted failed
    halt_reason: str = ""
    steps: int = 0                     # tool calls made (any tool)
    moved_minor: int = 0               # VND moved by executed transfers, integer
    blocked_invoices: set[str] = field(default_factory=set)
    blocked_payees: set[str] = field(default_factory=set)
    timeline: list[dict[str, Any]] = field(default_factory=list)
    gate_log: list[dict[str, Any]] = field(default_factory=list)
    final_answer: str = ""
    started_at: float = field(default_factory=time.time)
    ended_at: float = 0.0
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def note(self, kind: str, **kw: Any) -> None:
        with self._lock:
            self.timeline.append({"n": len(self.timeline) + 1, "kind": kind, **kw})

    def take_step(self) -> None:
        with self._lock:
            if self.steps >= self.max_steps:
                raise RunHalted("MAX_STEPS", f"{self.max_steps} tool calls reached")
            self.steps += 1

    def fallback_report(self) -> str:
        """Plain report built from the timeline when the model could not write one (the run was
        halted by the control system or by a bound). No model text, no personal data."""
        paid = [e for e in self.timeline if e["kind"] == "executed"]
        blocked = [e for e in self.timeline if e["kind"] == "blocked"]
        lines = [f"RUN {self.status.upper()} ({self.halt_reason or 'no reason'}), "
                 f"statement {self.statement_id}, account {self.account}.",
                 f"Paid {len(paid)} invoice(s), {self.moved_minor} VND in total:"]
        lines += [f"  {e['invoice_id']} {e['amount_minor']} VND {e['transfer_id']}" for e in paid]
        lines.append(f"Refused by the gate: {len(blocked)}; invoices left for a person: "
                     f"{', '.join(sorted(self.blocked_invoices)) or 'none'}.")
        return "\n".join(lines)

    def public(self) -> dict[str, Any]:
        return {
            "run_id": self.run_id, "scenario": self.scenario, "statement_id": self.statement_id,
            "account": self.account, "status": self.status, "halt_reason": self.halt_reason, "steps": self.steps,
            "max_steps": self.max_steps, "moved_minor": self.moved_minor,
            "max_total_minor": self.max_total_minor,
            "blocked_invoices": sorted(self.blocked_invoices),
            "blocked_payees": sorted(self.blocked_payees),
            "timeline": list(self.timeline), "gate_decisions": list(self.gate_log),
            "final_answer": self.final_answer,
        }
