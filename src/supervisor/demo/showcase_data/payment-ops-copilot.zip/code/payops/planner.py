"""The planner loop. Upstream: langchain-ai/deepagents (MIT), ``create_deep_agent``: a tool-calling
loop (v0.7.30). This file adapts it:

* only the three bank tools are offered to the model; the upstream file,
  shell and sub-agent tools are removed (HarnessProfile.excluded_tools);
* upstream v0.7.30 has no planning tool any more, so the plan is the model's own first message
  (the prompt asks for it); it is recorded in the timeline;
* the loop is bounded: a tool-call budget, a total-VND budget and a graph recursion limit, all
  enforced in code (``RunState``, ``tools.py``);
* there is NO approval step and no interrupt. Autonomy level: l4_autonomous_bounded.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from deepagents import HarnessProfile, create_deep_agent, register_harness_profile
from langchain_core.callbacks import BaseCallbackHandler
from langchain_openai import ChatOpenAI

from .bank import FakeCoreBank
from .config import Settings
from .gate import RunGate
from .runstate import RunHalted, RunState
from .tools import make_tools

PROMPT = (Path(__file__).parent / "prompts" / "system.md").read_text(encoding="utf-8")

# Upstream built-in tools we do not want a payments agent to have.
_EXCLUDED = frozenset(
    {"ls", "read_file", "write_file", "edit_file", "glob", "grep", "execute", "task", "delete"}
)
_registered = False


def _register_profile() -> None:
    global _registered
    if not _registered:
        register_harness_profile("openai", HarnessProfile(excluded_tools=_EXCLUDED))
        _registered = True


class Audit(BaseCallbackHandler):
    """Record what the model was offered and what it said (plan text), for the transcript."""

    def __init__(self, run: RunState) -> None:
        self.run = run
        self._offered = False

    def on_chat_model_start(self, serialized: Any, messages: Any, **kwargs: Any) -> None:
        if self._offered:
            return
        self._offered = True
        tools = (kwargs.get("invocation_params") or {}).get("tools") or []
        names = sorted(t.get("function", {}).get("name", "?") for t in tools)
        self.run.note("tools_offered", names=names)

    def on_llm_end(self, response: Any, **kwargs: Any) -> None:
        for gen in response.generations:
            for g in gen:
                text = (getattr(g, "text", "") or "").strip()
                if text:
                    self.run.note("say", text=text[:400])


def build_llm(s: Settings) -> ChatOpenAI:
    extra: dict[str, Any] = {}
    if s.llm_auth == "databricks_oauth":
        import httpx

        from .llm_auth import DatabricksOAuth

        extra = {"http_client": httpx.Client(auth=DatabricksOAuth(), timeout=s.llm_timeout_s)}
    return ChatOpenAI(
        base_url=s.llm_base_url, model=s.llm_model, api_key=s.llm_api_key, **extra,
        temperature=s.llm_temperature_milli / 1000, timeout=s.llm_timeout_s, max_retries=1,
        extra_body={"chat_template_kwargs": {"enable_thinking": False}},
    )


def run_job(run: RunState, s: Settings, bank: FakeCoreBank, http_gate: Any,
            llm: Any | None = None) -> RunState:
    """Run the whole reconciliation and payment job. Returns the finished RunState."""
    _register_profile()
    gate = RunGate(http_gate, run.run_id, s.consumer_id, run.instruction)
    tools = make_tools(run, bank, gate, s)
    agent = create_deep_agent(
        model=llm or build_llm(s), tools=tools, system_prompt=PROMPT,
        name="payment-ops-copilot",
    )
    run.status = "running"
    try:
        out = agent.invoke(
            {"messages": [{"role": "user", "content": run.instruction}]},
            config={"recursion_limit": 2 * run.max_steps + 10, "callbacks": [Audit(run)]},
        )
        msgs = out.get("messages", [])
        run.final_answer = str(msgs[-1].content) if msgs else ""
        run.status = "done"
    except RunHalted as exc:
        run.status, run.halt_reason = "halted", exc.reason
        run.note("halted", reason=exc.reason, detail=exc.detail)
    except Exception as exc:  # noqa: BLE001 - a run never takes the app down
        text = f"{type(exc).__name__}"
        if "recursion" in str(exc).lower():
            run.status, run.halt_reason = "halted", "RECURSION_LIMIT"
        else:
            run.status, run.halt_reason = "failed", text
        run.note("error", error=text)
    finally:
        run.gate_log = gate.log
        if not run.final_answer:
            run.final_answer = run.fallback_report()
        run.ended_at = __import__("time").time()
    return run
