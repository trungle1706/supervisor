"""Payments operations agent (candidate A3). Synthetic data only."""
import os

# The gate masks personal data in the arguments of a pii_export tool (add_payee). The SDK hands
# the masked values to the tool only when this switch is on in the AGENT process. The gateway
# needs INLINE_REDACTION_ENABLED=1 as well. On by default here; set to 0 to turn it off.
os.environ.setdefault("INLINE_REDACTION_ENABLED", "1")
