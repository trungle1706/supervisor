"""OpenAI-compatible chat client (httpx). Base URL, model and key come from the environment.
On Databricks the base URL is https://<host>/serving-endpoints and the key is an OAuth token.
This is the only network call besides the Supervisor gate."""
from __future__ import annotations

import os
import re

import httpx


def settings() -> dict:
    return {
        "base_url": os.environ.get("LLM_BASE_URL", "http://127.0.0.1:8001/v1").rstrip("/"),
        "model": os.environ.get("LLM_MODEL", "qwen3.8-27b-int4"),
        "api_key": os.environ.get("LLM_API_KEY", "none"),
    }


def api_shape() -> str:
    """LLM_API_SHAPE: chat (default, /chat/completions) or responses (/responses, AI Gateway)."""
    v = os.environ.get("LLM_API_SHAPE", "chat").strip().lower() or "chat"
    return v if v in ("chat", "responses") else "chat"


def _databricks_token() -> str:  # pragma: no cover - needs a workspace
    from databricks.sdk.core import Config

    return Config().authenticate()["Authorization"].split(" ", 1)[1]


def _auth(s: dict) -> dict:
    """LLM_AUTH=databricks_oauth: the App service principal token (refreshed by the SDK, never
    stored). Else the static LLM_API_KEY when set and not 'none'."""
    if os.environ.get("LLM_AUTH", "").strip().lower() == "databricks_oauth":
        return {"Authorization": f"Bearer {_databricks_token()}"}
    key = s["api_key"]
    return {"Authorization": f"Bearer {key}"} if key and key != "none" else {}


def _responses_chat(s: dict, messages: list[dict], max_tokens: int, temperature: float) -> str:
    system = "\n\n".join(m["content"] for m in messages if m["role"] == "system")
    items = []
    for m in messages:
        if m["role"] == "system":
            continue
        asst = m["role"] == "assistant"
        items.append({"role": "assistant" if asst else "user",
                      "content": [{"type": "output_text" if asst else "input_text",
                                   "text": m["content"]}]})
    body = {"model": s["model"], "max_output_tokens": max_tokens, "input": items,
            "temperature": temperature}
    if system:
        body["instructions"] = system
    r = httpx.post(f"{s['base_url']}/responses", json=body, headers=_auth(s),
                   timeout=float(os.environ.get("LLM_TIMEOUT_S", "120")))
    r.raise_for_status()
    data = r.json()
    if data.get("status") in ("incomplete", "failed"):
        raise RuntimeError(f"model reply {data.get('status')}")
    if any(p.get("type") == "refusal" for o in data.get("output") or []
           for p in o.get("content") or []):
        raise RuntimeError("model refused")
    text = data.get("output_text")
    if not isinstance(text, str) or not text:
        text = "".join(p.get("text", "") for o in data.get("output") or []
                       for p in o.get("content") or [] if p.get("type") == "output_text")
    return re.sub(r"<think>.*?</think>", "", text, flags=re.S).strip()


def chat(messages: list[dict], max_tokens: int = 700, temperature: float = 0.1) -> str:
    s = settings()
    if api_shape() == "responses":
        return _responses_chat(s, messages, max_tokens, temperature)
    body = {"model": s["model"], "messages": messages, "temperature": temperature,
            "max_tokens": max_tokens, "chat_template_kwargs": {"enable_thinking": False}}
    r = httpx.post(f"{s['base_url']}/chat/completions", json=body,
                   headers=_auth(s), timeout=float(os.environ.get("LLM_TIMEOUT_S", "120")))
    r.raise_for_status()
    text = r.json()["choices"][0]["message"].get("content") or ""
    return re.sub(r"<think>.*?</think>", "", text, flags=re.S).strip()
