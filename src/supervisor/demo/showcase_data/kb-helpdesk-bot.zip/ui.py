"""Browser UI and /status payload (single self-contained page, no CDN, no fonts). ASCII only."""
from __future__ import annotations

import html as _html

_PAGE = r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>__TITLE__</title><link rel="icon" href="data:,"><style>
:root{--bg:#f5f6f8;--card:#fff;--ink:#1b2430;--mut:#5f6b7a;--line:#dde2e8;--acc:#1b5fd1;--ok:#157f3b;--okbg:#e3f5e9;--bad:#b3261e;--badbg:#fde8e6;--grey:#6b7280;--greybg:#eceef1;--warn:#9a5b00;--warnbg:#fff1d6}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.45 system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif}
header{background:var(--card);border-bottom:1px solid var(--line)}
.wrap{max-width:900px;margin:0 auto;padding:0 16px}
header .wrap{padding:14px 16px;text-align:left}
header h1{margin:0;font-size:20px;font-weight:650}
header .sub{color:var(--mut);font-size:13px;margin-top:2px}
main.wrap{padding-top:16px;padding-bottom:40px}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:16px;margin-bottom:16px}
.card h2{margin:0 0 10px;font-size:16px}
.row{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.badge{display:inline-block;padding:8px 18px;border-radius:999px;font-weight:700;font-size:18px;letter-spacing:.04em}
.badge.ok{background:var(--okbg);color:var(--ok)}.badge.bad{background:var(--badbg);color:var(--bad)}.badge.grey{background:var(--greybg);color:var(--grey)}
.pill{display:inline-block;padding:1px 9px;border-radius:999px;font-size:12px;font-weight:700}
.pill.ok{background:var(--okbg);color:var(--ok)}.pill.bad{background:var(--badbg);color:var(--bad)}.pill.na{background:var(--greybg);color:var(--grey)}.pill.warn{background:var(--warnbg);color:var(--warn)}
table{border-collapse:collapse;width:100%;margin:10px 0}
td,th{text-align:left;padding:6px 8px;border-bottom:1px solid var(--line);vertical-align:top;font-size:14px;word-break:break-word}
th{color:var(--mut);font-weight:600;font-size:12px;text-transform:uppercase}
.mut{color:var(--mut);font-size:13px}.mono{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:12.5px}
button{font:inherit;border:1px solid var(--acc);background:var(--acc);color:#fff;border-radius:8px;padding:8px 16px;cursor:pointer}
button.sec{background:#fff;color:var(--acc)}button.red{background:var(--bad);border-color:var(--bad)}button:disabled{opacity:.5;cursor:default}
input,textarea{font:inherit;border:1px solid var(--line);border-radius:8px;padding:8px 10px;min-width:0}
.chat{display:flex;flex-direction:column;gap:10px;margin:8px 0 12px;max-height:480px;overflow:auto}
.msg{max-width:85%;padding:9px 13px;border-radius:14px;white-space:pre-wrap;word-break:break-word}
.msg.user{align-self:flex-end;background:var(--acc);color:#fff;border-bottom-right-radius:4px}
.msg.bot{align-self:flex-start;background:#eef1f5;border-bottom-left-radius:4px}
.msg.err{align-self:flex-start;background:var(--badbg);color:var(--bad)}
.meta{font-size:12px;color:var(--mut);margin-top:6px;white-space:normal}
.src{border-left:3px solid var(--line);padding:2px 8px;margin:4px 0;font-size:12.5px;color:var(--mut)}
.inp{display:flex;gap:8px}.inp input,.inp textarea{flex:1}
.blk{background:var(--badbg)}
pre{white-space:pre-wrap;word-break:break-word;margin:6px 0;font-size:12.5px}
@media(max-width:560px){.msg{max-width:96%}.inp{flex-wrap:wrap}}
</style></head><body>
<header><div class="wrap"><h1>__TITLE__</h1><div class="sub">Agent id: <span class="mono">__AGENT__</span> &middot; synthetic bank data</div></div></header>
<main class="wrap">
<section class="card"><div class="row" style="justify-content:space-between"><h2>Supervisor connection</h2><button class="sec" id="recheck" onclick="loadStatus()">Re-check</button></div><div id="status"></div></section>
<section class="card"><h2>Ask the policy assistant</h2>
<div class="chat" id="chat"></div>
<div class="inp"><input id="q" maxlength="500" placeholder="Ask about a bank policy (Vietnamese)" onkeydown="if(event.key==='Enter')send()"><button id="send" onclick="send()">Send</button></div></section></main><script>
const $=id=>document.getElementById(id);
function el(t,c,x){const e=document.createElement(t);if(c)e.className=c;if(x!==undefined&&x!==null)e.textContent=String(x);return e}
function clear(n){while(n.firstChild)n.removeChild(n.firstChild)}
async function api(method,path,body){
  const r=await fetch(path,{method:method,headers:{'Content-Type':'application/json'},body:body!==undefined?JSON.stringify(body):undefined});
  const t=await r.text();let j=null;try{j=JSON.parse(t)}catch(e){}
  if(!r.ok){let d=t.slice(0,400);if(j&&j.detail!==undefined)d=typeof j.detail==='string'?j.detail:JSON.stringify(j.detail);
    const err=new Error('HTTP '+r.status+': '+d);err.status=r.status;err.body=j;throw err}
  return j}
function gateLine(o){const p=[];if(!o)return '';
  ['status','rule_id','correlation_id'].forEach(k=>{if(o[k])p.push(k+': '+o[k])});return p.join('  |  ')}
function row(tb,k,v,cls){const tr=el('tr',cls);tr.appendChild(el('td','',k));const td=el('td');if(v instanceof Node)td.appendChild(v);else td.textContent=v;tr.appendChild(td);tb.appendChild(tr);return tr}
function pill(ok,t){if(ok===null||ok===undefined)return el('span','pill na',t||'n/a');return el('span','pill '+(ok?'ok':'bad'),t||(ok?'OK':'FAIL'))}
function renderStatus(s){
  const box=$('status');clear(box);
  const gc=(s.checks||{}).gate_check;
  let cls='grey',txt='NO GATE';
  if(s.gate_url){if(s.connected){cls='ok';txt='CONNECTED'}else{cls='bad';txt='NOT CONNECTED'}}
  const top=el('div','row');top.appendChild(el('span','badge '+cls,txt));top.appendChild(el('span','',s.summary||''));box.appendChild(top);
  const tb=el('table');const ck=s.checks||{};
  if(ck.token){const t=ck.token;row(tb,'Service-principal token',el('span','',''));const c=tb.lastChild.lastChild;c.appendChild(pill(t.ok===null?null:!!t.ok));c.appendChild(document.createTextNode(' '+(t.ok===null?(t.note||''):(t.ok?('JWT: '+t.jwt):t.error))))}
  if(ck.supervisor_healthz){const h=ck.supervisor_healthz;const ok=h.status===200;const c=el('span');c.appendChild(pill(ok));c.appendChild(document.createTextNode(' '+(h.error?h.error:('HTTP '+h.status+(h.status===302?' (no token accepted)':'')))));row(tb,'Supervisor /healthz',c)}
  if(gc){const c=el('span');c.appendChild(pill(!!gc.ok));
    c.appendChild(document.createTextNode(' '+(gc.error?gc.error:('allow='+gc.allow+', action='+gc.action+', rule_id='+gc.rule_id))));row(tb,'Gate check (read-only tool)',c);
    if(!gc.error){row(tb,'Correlation id',gc.correlation_id||'-');row(tb,'Agent state',gc.agent_state||'-');row(tb,'Latency',(gc.latency_ms===undefined||gc.latency_ms===null)?'-':(gc.latency_ms+' ms'))}}
  box.appendChild(tb);
  box.appendChild(el('div','mut','Gate URL: '+(s.gate_url||'(not set)')+'   |   Credential kind: '+(s.credential_kind||'-')));
  box.appendChild(el('p','mut','Open the Supervisor console, Supervisor \u203a Activity, to see this check as a row for '+(s.agent_id||'')+'.'))}
async function loadStatus(){
  const b=$('recheck');b.disabled=true;const box=$('status');clear(box);box.appendChild(el('span','mut','Checking...'));
  try{renderStatus(await api('GET','status'))}catch(e){clear(box);box.appendChild(el('div','msg err','Status failed: '+e.message))}
  b.disabled=false}


const hist=[];
function bubble(cls,text){const m=el('div','msg '+cls,text);$('chat').appendChild(m);$('chat').scrollTop=1e9;return m}
async function send(){
  const q=$('q').value.trim();if(q.length<2)return;$('q').value='';$('send').disabled=true;
  bubble('user',q);const wait=bubble('bot','...');
  try{const r=await api('POST','chat',{question:q,history:hist.slice(-10)});
    wait.textContent=r.answer||'';hist.push({role:'user',text:q.slice(0,800)});hist.push({role:'assistant',text:String(r.answer||'').slice(0,800)});
    const meta=el('div','meta');
    (r.sources||[]).forEach((s,i)=>{const d=el('div','src');d.textContent='['+(i+1)+'] '+s.doc_id+' - '+s.title+', '+s.section;meta.appendChild(d)});
    (r.tool_calls||[]).forEach(t=>{meta.appendChild(el('div','',('tool '+t.tool+': '+t.outcome+(t.rule_id?(' ('+t.rule_id+')'):''))))});
    const g=gateLine(r);if(g)meta.appendChild(el('div','',g));
    wait.appendChild(meta);
  }catch(e){wait.className='msg err';wait.textContent=e.message}
  $('send').disabled=false;$('q').focus()}

loadStatus();
</script></body></html>
'''


def render_page(title: str, agent_id: str) -> str:
    return _PAGE.replace('__TITLE__', _html.escape(title)).replace('__AGENT__', _html.escape(agent_id))


_BAD_RULES = ("GATE-UNREACHABLE", "GATE-AUTH", "GATE-MISSING")


def _default_http_get(url, headers):
    import httpx

    return httpx.get(url, headers=headers, timeout=10, follow_redirects=False).status_code


def build_status(app_name, agent_id, agent_version, gate_url, kind, gate, tool, token_fn, http_get=None):
    """The /status payload. Never raises; every failure is reported as data. A token is never
    returned: only whether it was obtained and whether it looks like a JWT."""
    checks = {}
    out = {"app": app_name, "agent_id": agent_id, "gate_url": gate_url or "", "credential_kind": kind,
           "checks": checks, "connected": False, "summary": ""}
    try:
        if not gate_url or gate is None:
            out["summary"] = "No Supervisor gate is configured (SUPERVISOR_GATE_URL is empty), so this App is not connected."
            return out
        tok = None
        if token_fn is None:
            checks["token"] = {"ok": None, "note": "not used for " + str(kind)}
        else:
            try:
                tok = token_fn()
                checks["token"] = {"ok": True, "jwt": str(tok).count(".") == 2}
            except Exception as exc:  # noqa: BLE001
                checks["token"] = {"ok": False, "error": (type(exc).__name__ + ": " + str(exc))[:200]}
        try:
            hdr = {"Authorization": "Bearer " + str(tok)} if tok else {}
            checks["supervisor_healthz"] = {"status": (http_get or _default_http_get)(gate_url.rstrip("/") + "/healthz", hdr)}
        except Exception as exc:  # noqa: BLE001
            checks["supervisor_healthz"] = {"error": (type(exc).__name__ + ": " + str(exc))[:200]}
        try:
            d = gate.check(agent_id, agent_version, tool, {"probe": "status"},
                           {"probe": True, "consumer_id": "status-page"})
            rule = d.get("rule_id")
            checks["gate_check"] = {"ok": rule not in _BAD_RULES, "allow": d.get("allow"), "action": d.get("action"),
                                    "rule_id": rule, "correlation_id": d.get("correlation_id") or d.get("decision_id"),
                                    "agent_state": d.get("agent_state"),
                                    "latency_ms": d.get("latency_ms")}
            out["connected"] = rule not in _BAD_RULES
        except Exception as exc:  # noqa: BLE001
            checks["gate_check"] = {"ok": False, "error": (type(exc).__name__ + ": " + str(exc))[:200]}
        gc = checks["gate_check"]
        if out["connected"]:
            out["summary"] = "Connected: the Supervisor gate answered " + str(gc.get("action")) + " (" + str(gc.get("rule_id")) + ")."
        else:
            out["summary"] = "Not connected: " + str(gc.get("rule_id") or gc.get("error") or "no decision") + "."
    except Exception as exc:  # noqa: BLE001
        out["summary"] = "Status check failed: " + type(exc).__name__
    return out
