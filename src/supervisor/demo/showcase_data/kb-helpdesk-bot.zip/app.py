"""Bank knowledge chatbot (A1) as a Databricks App: /healthz and /chat.
The Supervisor FastAPI middleware checks every inbound request and every response; the tool
search_policies is gated in code (supervised_tool). Shadow or enforce is decided by the Supervisor
policy, not by this app."""
from __future__ import annotations

import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE / "src"))  # vendored Supervisor client (stdlib only), same as PYTHONPATH=src

import httpx
from fastapi import FastAPI, HTTPException, Response
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field
from typing import Literal

from supervisor.gateway.adapters.fastapi_mw import SupervisorASGIMiddleware

import agent as ag
import ui

SKIP_PATHS = ("/healthz", "/status", "/favicon.ico")  # prefix match in the middleware: never add "/"


class PageBypass:
    """The Supervisor middleware matches skip_paths by prefix, so "/" cannot be listed. This wrapper
    lets exactly GET / (the static page) through and gives every other request to the middleware."""

    def __init__(self, app, **kw):
        self.app = app
        self.gated = SupervisorASGIMiddleware(app, **kw)

    async def __call__(self, scope, receive, send):
        if scope["type"] == "http" and scope.get("path") == "/" and scope.get("method") == "GET":
            await self.app(scope, receive, send)
            return
        await self.gated(scope, receive, send)


app = FastAPI(title="Bank KB chatbot (synthetic)")
if ag.GATE is not None:
    app.add_middleware(PageBypass, gate=ag.GATE, agent_id=ag.AGENT_ID,
                       agent_version=ag.AGENT_VERSION, fail_mode=os.environ.get("SUPERVISOR_FAIL_MODE", "closed"),
                       skip_paths=SKIP_PATHS)


class Turn(BaseModel):
    role: Literal["user", "assistant"]
    text: str = Field(max_length=800)


class ChatRequest(BaseModel):
    question: str = Field(min_length=2, max_length=500)
    history: list[Turn] = Field(default_factory=list, max_length=10)


@app.get("/healthz")
def healthz(probe: int = 0):
    out = {"status": "ok", "documents": ag.KB.doc_count, "chunks": len(ag.KB.chunks), "gate_configured": ag.GATE is not None}
    if probe and ag.GATE is not None:
        out["probe"] = _probe_gate()
    return out


def _probe_gate() -> dict:
    """Diagnostic (sandbox): can this App reach the Supervisor with its own token?
    Reports status codes and the redirect target only; the token itself is never returned."""
    rep: dict = {"gate_url": ag.GATE.base_url}
    try:
        from llm import _databricks_token
        tok = _databricks_token()
        rep["token"] = {"ok": True, "length": len(tok), "jwt": tok.count(".") == 2}
    except Exception as exc:  # noqa: BLE001
        rep["token"] = {"ok": False, "error": type(exc).__name__ + ": " + str(exc)[:200]}
        return rep
    hdr = {"Authorization": f"Bearer {tok}"}
    for name, method, path, body in (
        ("get_healthz", "GET", "/healthz", None),
        ("post_gate", "POST", "/v1/gate/check", b"{}"),
    ):
        try:
            r = httpx.request(method, ag.GATE.base_url + path, headers={**hdr, "Content-Type": "application/json"},
                              content=body, timeout=10, follow_redirects=False)
            rep[name] = {"status": r.status_code, "location": r.headers.get("location", "")[:300],
                         "body_head": r.text[:160]}
        except Exception as exc:  # noqa: BLE001
            rep[name] = {"error": type(exc).__name__ + ": " + str(exc)[:200]}
    return rep


@app.post("/chat")
def chat(req: ChatRequest):
    try:
        return ag.run_agent(req.question.strip(), [t.model_dump() for t in req.history])
    except httpx.HTTPError:
        raise HTTPException(status_code=503, detail="The language model endpoint is not reachable.")


@app.get("/", response_class=HTMLResponse)
def index() -> HTMLResponse:
    return HTMLResponse(ui.render_page("Bank KB chatbot", ag.AGENT_ID))


@app.get("/favicon.ico")
def favicon() -> Response:
    return Response(status_code=204)


@app.get("/status")
def status() -> dict:
    """Connection status for the browser page. Never raises; the token is never returned."""
    kind = os.environ.get("SUPERVISOR_CREDENTIAL_KIND", "hmac").strip().lower()
    try:
        token_fn = None
        if kind == "databricks_oauth":
            from llm import _databricks_token as token_fn  # noqa: N813
        gate = ag.GATE
        return ui.build_status("A1 Bank KB chatbot", ag.AGENT_ID, ag.AGENT_VERSION,
                               getattr(gate, "base_url", "") if gate is not None else "", kind, gate,
                               "http_inbound", token_fn)
    except Exception as exc:  # noqa: BLE001
        return {"app": "A1 Bank KB chatbot", "agent_id": ag.AGENT_ID, "gate_url": "", "credential_kind": kind,
                "checks": {}, "connected": False, "summary": "Status check failed: " + type(exc).__name__}
